package com.mrcaracal.havadurumumrc.model


import com.google.gson.annotations.SerializedName

data class Clouds(
    val all: Int
)