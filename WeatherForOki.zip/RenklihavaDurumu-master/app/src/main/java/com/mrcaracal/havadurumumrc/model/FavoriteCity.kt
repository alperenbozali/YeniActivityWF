package com.mrcaracal.havadurumumrc.model

data class FavoriteCity(val name:String,val degree:String,val weathertype:String)
