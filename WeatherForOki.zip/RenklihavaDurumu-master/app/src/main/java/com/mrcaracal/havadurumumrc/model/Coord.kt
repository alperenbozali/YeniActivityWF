package com.mrcaracal.havadurumumrc.model


import com.google.gson.annotations.SerializedName

data class Coord(
    val lat: Double,
    val lon: Double
)